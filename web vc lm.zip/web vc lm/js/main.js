// ===== THEME TOGGLE LOGIC =====
function applyTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
  localStorage.setItem('theme', theme);
  
  // Update all theme buttons/switches in the DOM
  const navToggles = document.querySelectorAll('.theme-switch-btn');
  navToggles.forEach(toggle => {
    toggle.innerHTML = theme === 'dark' ? '🌙' : '☀️';
  });
}

function toggleTheme() {
  const currentTheme = document.documentElement.getAttribute('data-theme') || 'light';
  const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
  applyTheme(newTheme);
}

// Auto-run on script load to avoid screen flashing
(function() {
  const savedTheme = localStorage.getItem('theme');
  const systemPrefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  const initialTheme = savedTheme || (systemPrefersDark ? 'dark' : 'light');
  document.documentElement.setAttribute('data-theme', initialTheme);
})();

document.addEventListener('DOMContentLoaded', () => {
  const currentTheme = document.documentElement.getAttribute('data-theme') || 'light';
  applyTheme(currentTheme);
});

// ===== MOBILE MENU =====
function toggleMenu() {
  document.querySelector('.nav-links').classList.toggle('active');
}

// ===== NAVBAR SCROLL EFFECT =====
window.addEventListener('scroll', () => {
  const navbar = document.querySelector('.navbar');
  if (navbar) {
    navbar.classList.toggle('scrolled', window.scrollY > 50);
  }
});

// ===== SCROLL ANIMATIONS =====
const observerOptions = {
  threshold: 0.1,
  rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.style.opacity = '1';
      entry.target.style.transform = 'translateY(0)';
    }
  });
}, observerOptions);

document.querySelectorAll('.animate-fade-in-up, .animate-slide-left, .animate-slide-right').forEach(el => {
  observer.observe(el);
});

// ===== PASSWORD TOGGLE =====
function togglePassword(inputId) {
  const input = document.getElementById(inputId);
  if (input) {
    input.type = input.type === 'password' ? 'text' : 'password';
  }
}

// ===== PASSWORD STRENGTH =====
function checkPasswordStrength(password, barId) {
  const bar = document.getElementById(barId);
  if (!bar) return;

  bar.className = 'password-strength-bar';

  if (password.length === 0) {
    bar.style.width = '0';
    return;
  }

  let strength = 0;
  if (password.length >= 8) strength++;
  if (/[A-Z]/.test(password)) strength++;
  if (/[0-9]/.test(password)) strength++;
  if (/[^A-Za-z0-9]/.test(password)) strength++;

  if (strength <= 1) {
    bar.classList.add('strength-weak');
  } else if (strength <= 3) {
    bar.classList.add('strength-medium');
  } else {
    bar.classList.add('strength-strong');
  }
}

document.getElementById('password')?.addEventListener('input', (e) => {
  checkPasswordStrength(e.target.value, 'strengthBar');
});

document.getElementById('newPassword')?.addEventListener('input', (e) => {
  checkPasswordStrength(e.target.value, 'newStrengthBar');
});

// ===== FORM HANDLERS =====
function handleRegister(e) {
  e.preventDefault();
  const password = document.getElementById('password').value;
  const confirmPassword = document.getElementById('confirmPassword').value;

  if (password !== confirmPassword) {
    alert('Mật khẩu xác nhận không khớp!');
    return;
  }

  const btn = e.target.querySelector('button[type="submit"]');
  btn.textContent = 'Đang tạo tài khoản...';
  btn.disabled = true;

  setTimeout(() => {
    alert('Đăng ký thành công! Chuyển đến trang đăng nhập.');
    window.location.href = 'dang-nhap.html';
  }, 1500);
}

function handleLogin(e) {
  e.preventDefault();
  const btn = e.target.querySelector('button[type="submit"]');
  btn.textContent = 'Đang đăng nhập...';
  btn.disabled = true;

  setTimeout(() => {
    alert('Đăng nhập thành công!');
    window.location.href = 'index.html';
  }, 1500);
}

// ===== FORGOT PASSWORD FLOW =====
let currentStep = 1;

function goToStep(step) {
  const currentPanel = document.getElementById('step' + currentStep);
  const nextPanel = document.getElementById('step' + step);

  if (currentPanel && nextPanel) {
    currentPanel.classList.remove('active');
    currentPanel.classList.add('slide-out');

    setTimeout(() => {
      currentPanel.classList.remove('slide-out');
      nextPanel.classList.add('active', 'slide-in');

      setTimeout(() => {
        nextPanel.classList.remove('slide-in');
      }, 400);
    }, 300);
  }

  updateStepIndicators(step);
  currentStep = step;
}

function updateStepIndicators(step) {
  for (let i = 1; i <= 3; i++) {
    const dot = document.getElementById('dot' + i);
    const label = document.getElementById('label' + i);

    if (dot) {
      dot.classList.remove('active', 'completed');
      if (i < step) dot.classList.add('completed');
      if (i === step) dot.classList.add('active');
    }

    if (label) {
      label.classList.toggle('active', i === step);
    }
  }
}

function goToStep2(e) {
  e.preventDefault();
  const email = document.getElementById('resetEmail').value;
  document.getElementById('displayEmail').textContent = email;

  const btn = e.target.querySelector('button[type="submit"]');
  btn.textContent = 'Đang gửi...';
  btn.disabled = true;

  setTimeout(() => {
    btn.textContent = 'Gửi mã xác nhận';
    btn.disabled = false;
    goToStep(2);
    startCountdown();
    document.querySelector('.otp-input')?.focus();
  }, 1500);
}

function goToStep3(e) {
  e.preventDefault();
  const btn = e.target.querySelector('button[type="submit"]');
  btn.textContent = 'Đang xác nhận...';
  btn.disabled = true;

  setTimeout(() => {
    btn.textContent = 'Xác nhận';
    btn.disabled = false;
    goToStep(3);
  }, 1500);
}

function handleResetPassword(e) {
  e.preventDefault();
  const newPassword = document.getElementById('newPassword').value;
  const confirmNewPassword = document.getElementById('confirmNewPassword').value;

  if (newPassword !== confirmNewPassword) {
    alert('Mật khẩu xác nhận không khớp!');
    return;
  }

  const btn = e.target.querySelector('button[type="submit"]');
  btn.textContent = 'Đang cập nhật...';
  btn.disabled = true;

  setTimeout(() => {
    document.getElementById('step3').classList.remove('active');
    document.getElementById('step4').classList.add('active');
    updateStepIndicators(4);
  }, 1500);
}

// ===== OTP INPUT HANDLING =====
document.querySelectorAll('.otp-input').forEach((input, index, inputs) => {
  // Chỉ cho phép nhập số
  input.setAttribute('inputmode', 'numeric');
  input.setAttribute('pattern', '[0-9]*');

  input.addEventListener('keydown', (e) => {
    // Cho phép: Backspace, Delete, Tab, Arrow keys
    if (['Backspace', 'Delete', 'Tab', 'ArrowLeft', 'ArrowRight'].includes(e.key)) {
      if (e.key === 'Backspace') {
        e.preventDefault();
        input.value = '';
        if (index > 0) inputs[index - 1].focus();
      }
      return;
    }
    // Chặn ký tự không phải số
    if (!/^[0-9]$/.test(e.key)) {
      e.preventDefault();
      return;
    }
    // Nếu ô đã có giá trị, xóa và nhập mới
    if (input.value) {
      e.preventDefault();
      input.value = e.key;
      if (index < inputs.length - 1) inputs[index + 1].focus();
    }
  });

  input.addEventListener('input', (e) => {
    // Chỉ lấy ký tự số cuối cùng
    const digit = e.target.value.replace(/\D/g, '').slice(-1);
    input.value = digit;
    if (digit && index < inputs.length - 1) {
      inputs[index + 1].focus();
    }
  });

  // Chọn toàn bộ khi focus để dễ thay thế
  input.addEventListener('focus', () => {
    setTimeout(() => input.select(), 0);
  });

  input.addEventListener('paste', (e) => {
    e.preventDefault();
    const paste = (e.clipboardData || window.clipboardData).getData('text');
    const digits = paste.replace(/\D/g, '').slice(0, 6);

    digits.split('').forEach((digit, i) => {
      if (inputs[i]) {
        inputs[i].value = digit;
      }
    });

    if (digits.length > 0) {
      inputs[Math.min(digits.length, inputs.length - 1)].focus();
    }
  });
});

// ===== RESEND CODE COUNTDOWN =====
let countdownTimer;

function startCountdown() {
  let seconds = 60;
  const countdownEl = document.getElementById('countdown');

  clearInterval(countdownTimer);
  countdownEl.textContent = ` (${seconds}s)`;

  countdownTimer = setInterval(() => {
    seconds--;
    countdownEl.textContent = seconds > 0 ? ` (${seconds}s)` : '';

    if (seconds <= 0) {
      clearInterval(countdownTimer);
    }
  }, 1000);
}

function resendCode(e) {
  e.preventDefault();
  const countdownEl = document.getElementById('countdown');

  if (countdownEl.textContent) {
    alert('Vui lòng đợi trước khi gửi lại mã!');
    return;
  }

  alert('Mã xác nhận mới đã được gửi!');
  startCountdown();
}
