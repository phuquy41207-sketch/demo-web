(() => {
  'use strict';

  const canvas = document.getElementById('world');
  const ctx = canvas.getContext('2d');
  const $ = (id) => document.getElementById(id);

  const FIXED_DT = 1 / 60;
  const MAX_STEPS = 5;
  const HISTORY_MAX = 180;
  const EVENT_MAX = 80;
  const SAVE_KEY = 'thegioisong_config_v2';
  const WELCOME_KEY = 'thegioisong_welcome_v2';
  const USERS_KEY = 'thegioisong_users_v1';
  const SESSION_KEY = 'thegioisong_session_v1';

  let currentUser = null;

  let W = 900;
  let H = 560;
  let dpr = 1;
  let game = 'bio';
  let running = true;
  let slow = false;
  let simFrame = 0;
  let toolDown = false;
  let activePointerId = null;
  let dragStart = null;
  let dragNow = null;

  let organisms = [];
  let foods = [];
  let obstacles = [];
  let bodies = [];
  let stars = [];
  let structures = []; // Công trình: nhà ở (house), tháp phòng thủ (tower)

  let selectedBio = null;
  let selectedBody = null;
  let showTrails = true;
  let showVectors = true;
  let orbitAssist = true;
  let gravityPower = 1;
  let simSpeed = 1;

  let bioEffects = { sonar: 0, shield: 0, mutation: 0 };
  let gravityPulse = 0;
  let stasisFrames = 0;
  const skillCooldown = {};

  let lastTime = performance.now();
  let accTime = 0;

  let prevOrganismCount = -1;
  let extinctionLogged = false;

  const history = [];
  const events = [];

  const rand = (a, b) => a + Math.random() * (b - a);
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
  const angle = (a, b) => Math.atan2(b.y - a.y, b.x - a.x);

  function logEvent(type, message) {
    const entry = { t: simFrame, type, message };
    events.unshift(entry);
    if (events.length > EVENT_MAX) events.pop();
    renderEventLog();
  }

  function renderEventLog() {
    const el = $('eventLog');
    el.innerHTML = events
      .map(
        (e) =>
          `<p class="evt-${e.type}"><span style="color:#6a8299">#${e.t}</span> ${e.message}</p>`
      )
      .join('');
  }

  function pushHistory() {
    if (simFrame % 20 !== 0) return;
    const row =
      game === 'bio'
        ? {
            mode: 'bio',
            frame: simFrame,
            organisms: organisms.length,
            foods: foods.length,
            avgEnergy: organisms.length
              ? organisms.reduce((s, o) => s + o.energy, 0) / organisms.length
              : 0,
            maxGen: organisms.reduce((m, o) => Math.max(m, o.gen), 0),
          }
        : {
            mode: 'gravity',
            frame: simFrame,
            bodies: bodies.length,
            totalMass: bodies.reduce((s, b) => s + b.mass, 0),
            blackholes: bodies.filter((b) => b.type === 'blackhole').length,
          };
    history.push(row);
    if (history.length > HISTORY_MAX) history.shift();
    drawCharts();
  }

  function drawLineChart(canvasEl, series, colors, labels) {
    const c = canvasEl.getContext('2d');
    const w = canvasEl.width;
    const h = canvasEl.height;
    c.clearRect(0, 0, w, h);
    c.fillStyle = '#0a111b';
    c.fillRect(0, 0, w, h);
    if (series[0].length < 2) {
      c.fillStyle = '#6a8299';
      c.font = '11px system-ui';
      c.fillText('Đang thu thập dữ liệu…', 8, h / 2);
      return;
    }
    const all = series.flat();
    const min = Math.min(...all);
    const max = Math.max(...all, min + 1);
    const pad = 6;
    series.forEach((data, si) => {
      c.strokeStyle = colors[si];
      c.lineWidth = 1.5;
      c.beginPath();
      data.forEach((v, i) => {
        const x = pad + (i / (data.length - 1)) * (w - pad * 2);
        const y = h - pad - ((v - min) / (max - min)) * (h - pad * 2);
        if (i === 0) c.moveTo(x, y);
        else c.lineTo(x, y);
      });
      c.stroke();
    });
    c.fillStyle = '#8ea2b9';
    c.font = '9px system-ui';
    labels.forEach((lb, i) => {
      c.fillStyle = colors[i];
      c.fillRect(8, 8 + i * 12, 8, 8);
      c.fillStyle = '#8ea2b9';
      c.fillText(lb, 20, 16 + i * 12);
    });
  }

  function drawCharts() {
    const bioRows = history.filter((r) => r.mode === 'bio');
    const gravRows = history.filter((r) => r.mode === 'gravity');
    if (bioRows.length) {
      drawLineChart(
        $('chartBio'),
        [
          bioRows.map((r) => r.organisms),
          bioRows.map((r) => r.foods),
          bioRows.map((r) => r.avgEnergy),
        ],
        ['#28d9c3', '#66e7ff', '#ffb454'],
        ['Sinh vật', 'Thức ăn', 'Năng lượng TB']
      );
    }
    if (gravRows.length) {
      drawLineChart(
        $('chartGrav'),
        [gravRows.map((r) => r.bodies), gravRows.map((r) => r.totalMass / 10)],
        ['#a78bfa', '#ff9b54'],
        ['Số thiên thể', 'Khối lượng/10']
      );
    }
  }

  function resize() {
    const r = canvas.getBoundingClientRect();
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    W = Math.max(280, r.width);
    H = Math.max(280, r.height);
    canvas.width = Math.round(W * dpr);
    canvas.height = Math.round(H * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    makeStars();
  }

  function makeStars() {
    stars = Array.from({ length: Math.floor((W * H) / 5000) }, () => ({
      x: Math.random() * W,
      y: Math.random() * H,
      r: rand(0.35, 1.5),
      a: rand(0.15, 0.7),
      p: rand(0, 6),
    }));
  }

  function resetPointerState() {
    toolDown = false;
    dragStart = null;
    dragNow = null;
    if (activePointerId != null) {
      try {
        canvas.releasePointerCapture(activePointerId);
      } catch (_) {}
      activePointerId = null;
    }
  }

  function spawnFood(x = rand(20, W - 20), y = rand(20, H - 20), n = 1) {
    for (let i = 0; i < n; i++) {
      foods.push({
        x: x + rand(-16, 16),
        y: y + rand(-16, 16),
        r: rand(2, 4),
        energy: rand(13, 23),
      });
    }
  }

  function inheritTrait(parent, key, delta, min, max, fallback) {
    if (!parent) return fallback();
    return clamp(parent[key] + rand(-delta, delta), min, max);
  }

  function makeOrganism(x = rand(20, W - 20), y = rand(20, H - 20), parent = null) {
    const mut = +$('mutation').value / 100;
    const kind =
      parent != null
        ? parent.kind
        : Math.random() < 0.22
          ? 'predator'
          : 'grazer';
    const o = {
      x,
      y,
      vx: rand(-1, 1),
      vy: rand(-1, 1),
      r: inheritTrait(parent, 'r', 0.8, 3.5, 8, () => rand(4.5, 7)),
      energy: parent ? parent.energy * 0.45 : rand(55, 100),
      speed: inheritTrait(parent, 'speed', 0.25, 0.55, 2.6, () => rand(0.8, 1.7)),
      vision: inheritTrait(parent, 'vision', 12, 35, 130, () => rand(55, 100)),
      hue: parent
        ? (parent.hue + rand(-22 - mut * 40, 22 + mut * 40) + 360) % 360
        : rand(165, 205),
      age: 0,
      gen: parent ? parent.gen + 1 : 1,
      kind,
      cool: rand(0, 80),
      maxAge: inheritTrait(parent, 'maxAge', 400, 5000, 12000, () => rand(6500, 9500)),
    };
    if (kind === 'predator') {
      o.speed = clamp(o.speed * 1.08, 0.7, 2.8);
      o.vision = clamp(o.vision * 0.92, 40, 120);
      o.r = clamp(o.r * 1.05, 4, 9);
    }
    organisms.push(o);
    return o;
  }

  function newBio() {
    organisms = [];
    foods = [];
    obstacles = [];
    structures = [];
    selectedBio = null;
    extinctionLogged = false;
    prevOrganismCount = -1;
    const n = +$('population').value;
    for (let i = 0; i < n; i++) {
      // 45% ăn cỏ, 25% săn mồi, 20% thợ xây, 10% xâm chiếm
      const rk = Math.random();
      const kind = rk < 0.45 ? 'grazer' : rk < 0.70 ? 'predator' : rk < 0.90 ? 'builder' : 'invader';
      makeAdvancedOrganism(rand(20, W - 20), rand(20, H - 20), null, kind);
    }
    for (let i = 0; i < +$('foodRate').value; i++) spawnFood();
    for (let i = 0; i < 3; i++) {
      const x = rand(50, W - 100);
      const y = rand(50, H - 100);
      obstacles.push({ x, y, x2: x + rand(35, 100), y2: y + rand(10, 40), type: 'rock' });
    }
    $('eventText').textContent = 'Đã khởi tạo sinh quyển mới.';
    logEvent('system', 'Khởi tạo sinh quyển mới với 4 chủng loại.');
    updateInspectPanel();
  }

  function addObstacle(x, y, x2, y2, type) {
    obstacles.push({ x, y, x2, y2, type });
  }

  function bodyDefaults(type, mass, x, y, vx, vy) {
    const scale = type === 'blackhole' ? 1.5 : type === 'sun' ? 1.2 : 1;
    const m = mass * scale;
    return {
      x,
      y,
      vx,
      vy,
      mass: m,
      r:
        type === 'blackhole'
          ? Math.max(8, Math.sqrt(m) * 1.1)
          : type === 'sun'
            ? Math.max(7, Math.sqrt(m))
            : Math.max(2.5, Math.sqrt(m) * 0.7),
      type,
      hue: type === 'blackhole' ? 275 : type === 'sun' ? 35 : type === 'asteroid' ? 28 : 205,
      trail: [],
      dead: false,
      ax: 0,
      ay: 0,
    };
  }

  function newGravity() {
    bodies = [];
    selectedBody = null;
    for (let i = 0; i < 18; i++) {
      const a = rand(0, Math.PI * 2);
      const r = rand(55, Math.min(W, H) * 0.42);
      const mass = rand(5, 25);
      const x = W / 2 + Math.cos(a) * r;
      const y = H / 2 + Math.sin(a) * r;
      const v = Math.sqrt((2.1 * gravityPower * 85) / r);
      bodies.push(
        bodyDefaults('planet', mass, x, y, -Math.sin(a) * v, Math.cos(a) * v)
      );
      bodies[bodies.length - 1].type = Math.random() < 0.18 ? 'asteroid' : 'planet';
      bodies[bodies.length - 1].hue = rand(185, 255);
      bodies[bodies.length - 1].r = Math.max(2.5, Math.sqrt(mass) * 0.8);
    }
    bodies.push(bodyDefaults('blackhole', 280, W / 2, H / 2, 0, 0));
    logEvent('system', 'Khởi tạo phòng thí nghiệm trọng lực.');
    updateInspectPanel();
  }

  function syncBioToolButtons() {
    const t = $('bioTool').value;
    $('feedBtn').classList.toggle('selected', t === 'food');
    $('hazardBtn').classList.toggle('selected', t === 'lava');
  }

  function setGame(g) {
    resetPointerState();
    game = g;
    selectedBio = null;
    selectedBody = null;
    document.querySelectorAll('.tab').forEach((b) => {
      const on = b.dataset.game === g;
      b.classList.toggle('active', on);
      b.setAttribute('aria-selected', on ? 'true' : 'false');
    });
    $('bioControls').classList.toggle('hidden', g !== 'bio');
    $('gravityControls').classList.toggle('hidden', g !== 'gravity');
    $('bioSkills').classList.toggle('hidden', g !== 'bio');
    $('gravitySkills').classList.toggle('hidden', g !== 'gravity');
    $('bioStats').classList.toggle('hidden', g !== 'bio');
    $('gravStats').classList.toggle('hidden', g !== 'gravity');
    $('chartBioWrap').classList.toggle('hidden', g !== 'bio');
    $('chartLabelBio').classList.toggle('hidden', g !== 'bio');
    $('chartGravWrap').classList.toggle('hidden', g !== 'gravity');
    $('chartLabelGrav').classList.toggle('hidden', g !== 'gravity');
    $('app').classList.toggle('gravity-theme', g === 'gravity');
    $('modeLabel').textContent = g === 'bio' ? 'SINH QUYỂN' : 'TRỌNG LỰC';
    $('stageTitle').innerHTML =
      g === 'bio'
        ? 'SINH QUYỂN SỐNG <span style="color:var(--bio)">/ 01</span>'
        : 'PHÒNG THÍ NGHIỆM TRỌNG LỰC <span style="color:var(--purple)">/ 02</span>';
    $('stageSub').textContent =
      g === 'bio'
        ? 'Một hệ sinh thái được định hình bởi sinh tồn, thức ăn và thích nghi.'
        : 'Tạo vũ trụ thu nhỏ và quan sát lực hấp dẫn (mô hình minh họa).';
    $('hint').textContent =
      g === 'bio'
        ? 'Chọn công cụ rồi nhấp hoặc kéo trên bản đồ. Công cụ Xem để chọn sinh vật.'
        : 'Nhấp/kéo để tạo thiên thể. Chọn Xem để chọn và xóa từng vật thể.';
    $('hint').style.color = g === 'gravity' ? '#b5a5e9' : '';
    $('physicsNote').classList.toggle('hidden', g === 'bio');
    updatePauseUI();
    updateInspectPanel();
    drawCharts();
  }

  function updatePauseUI() {
    $('pauseBtn').textContent = running ? 'Ⅱ Tạm dừng' : '▶ Tiếp tục';
    $('runStatus').textContent = running ? 'MÔ PHỎNG ĐANG CHẠY' : 'MÔ PHỎNG ĐÃ TẠM DỪNG';
    $('statusDot').classList.toggle('paused', !running);
  }

  function pointerPos(e) {
    const r = canvas.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top };
  }

  function findClosestOrganism(p, maxD = 28) {
    let best = null;
    let bd = maxD;
    for (const o of organisms) {
      const d = dist(o, p);
      if (d < bd) {
        bd = d;
        best = o;
      }
    }
    return best;
  }

  function findClosestBody(p, maxD = 40) {
    let best = null;
    let bd = maxD;
    for (const b of bodies) {
      if (b.dead) continue;
      const d = dist(b, p);
      if (d < bd + b.r) {
        bd = d;
        best = b;
      }
    }
    return best;
  }

  function eraseNear(p) {
    if (game === 'bio') {
      foods = foods.filter((f) => dist(f, p) > 30);
      obstacles = obstacles.filter(
        (o) => dist({ x: (o.x + o.x2) / 2, y: (o.y + o.y2) / 2 }, p) > 35
      );
      for (let i = organisms.length - 1; i >= 0; i--) {
        if (dist(organisms[i], p) < 32) organisms.splice(i, 1);
      }
      if (selectedBio && !organisms.includes(selectedBio)) selectedBio = null;
    } else {
      for (let i = bodies.length - 1; i >= 0; i--) {
        if (!bodies[i].dead && dist(bodies[i], p) < bodies[i].r + 20) {
          bodies.splice(i, 1);
        }
      }
      selectedBody = null;
    }
    updateInspectPanel();
  }

  function updateInspectPanel() {
    const panel = $('inspectPanel');
    const actions = $('inspectActions');
    if (game === 'bio' && selectedBio && organisms.includes(selectedBio)) {
      const o = selectedBio;
      const kindLabel = o.kind === 'predator' ? 'Săn mồi' : 'Ăn cỏ';
      panel.classList.remove('empty');
      panel.innerHTML = `<div><strong>${kindLabel}</strong></div>
        Năng lượng: <strong>${Math.round(o.energy)}</strong> · Tốc độ: <strong>${o.speed.toFixed(2)}</strong><br>
        Tầm nhìn: <strong>${Math.round(o.vision)}</strong> · Tuổi: <strong>${o.age}</strong> · Thế hệ: <strong>${o.gen}</strong>`;
      actions.classList.remove('hidden');
    } else if (game === 'gravity' && selectedBody && bodies.includes(selectedBody) && !selectedBody.dead) {
      const b = selectedBody;
      const sp = Math.hypot(b.vx, b.vy);
      const typeNames = {
        planet: 'Hành tinh',
        asteroid: 'Tiểu hành tinh',
        sun: 'Ngôi sao',
        blackhole: 'Hố đen',
      };
      panel.classList.remove('empty');
      panel.innerHTML = `<div><strong>${typeNames[b.type] || b.type}</strong></div>
        Khối lượng: <strong>${Math.round(b.mass)}</strong> · Bán kính: <strong>${b.r.toFixed(1)}</strong><br>
        Vận tốc: <strong>${sp.toFixed(2)}</strong> (${b.vx.toFixed(2)}, ${b.vy.toFixed(2)}) · |a|: <strong>${Math.hypot(b.ax, b.ay).toFixed(3)}</strong>`;
      actions.classList.remove('hidden');
    } else {
      panel.classList.add('empty');
      panel.textContent =
        game === 'bio'
          ? 'Dùng công cụ Xem và nhấp vào sinh vật.'
          : 'Dùng công cụ Xem và nhấp vào thiên thể.';
      actions.classList.add('hidden');
      selectedBio = null;
      selectedBody = null;
    }
  }

  canvas.addEventListener('pointerdown', (e) => {
    if (e.button !== 0) return;
    const p = pointerPos(e);
    toolDown = true;
    dragStart = p;
    dragNow = p;
    activePointerId = e.pointerId;
    canvas.setPointerCapture(e.pointerId);

    if (game === 'bio') {
      const t = $('bioTool').value;
      if (t === 'food') spawnFood(p.x, p.y, 12);
      else if (t === 'inspect') {
        selectedBio = findClosestOrganism(p);
        updateInspectPanel();
      } else if (t === 'erase') eraseNear(p);
      else addObstacle(p.x, p.y, p.x, p.y, t);
    } else {
      const t = $('gravTool').value;
      if (t === 'inspect') {
        selectedBody = findClosestBody(p);
        updateInspectPanel();
      } else if (t === 'erase') eraseNear(p);
    }
  });

  canvas.addEventListener('pointermove', (e) => {
    const p = pointerPos(e);
    dragNow = p;
    if (!toolDown) return;
    if (game === 'bio' && ['rock', 'lava'].includes($('bioTool').value)) {
      const o = obstacles[obstacles.length - 1];
      if (o) {
        o.x2 = p.x;
        o.y2 = p.y;
      }
    }
  });

  canvas.addEventListener('pointerup', (e) => {
    const p = pointerPos(e);
    toolDown = false;
    if (game === 'gravity' && dragStart) {
      const tool = $('gravTool').value;
      if (!['inspect', 'erase'].includes(tool)) {
        const dx = p.x - dragStart.x;
        const dy = p.y - dragStart.y;
        const mass = +$('mass').value;
        let vx = 0;
        let vy = 0;
        if (orbitAssist) {
          const dx0 = dragStart.x - W / 2;
          const dy0 = dragStart.y - H / 2;
          const r = Math.max(30, Math.hypot(dx0, dy0));
          const v = Math.sqrt((gravityPower * 130) / r);
          vx = (-dy0 / r) * v;
          vy = (dx0 / r) * v;
        }
        vx += clamp(dx * 0.035, -5, 5);
        vy += clamp(dy * 0.035, -5, 5);
        bodies.push(bodyDefaults(tool, mass, dragStart.x, dragStart.y, vx, vy));
        logEvent('system', `Tạo ${tool} khối lượng ~${Math.round(mass)}.`);
      }
    }
    dragStart = null;
    dragNow = null;
    if (activePointerId != null) {
      try {
        canvas.releasePointerCapture(activePointerId);
      } catch (_) {}
      activePointerId = null;
    }
  });

  canvas.addEventListener('pointercancel', resetPointerState);

  function pointSegmentDistance(p, o) {
    const x = o.x;
    const y = o.y;
    const dx = o.x2 - x;
    const dy = o.y2 - y;
    const l = dx * dx + dy * dy;
    const t = l ? clamp(((p.x - x) * dx + (p.y - y) * dy) / l, 0, 1) : 0;
    return Math.hypot(p.x - (x + t * dx), p.y - (y + t * dy));
  }

  function buildFoodGrid(cell = 48) {
    const grid = new Map();
    for (const f of foods) {
      const key = `${Math.floor(f.x / cell)},${Math.floor(f.y / cell)}`;
      if (!grid.has(key)) grid.set(key, []);
      grid.get(key).push(f);
    }
    return grid;
  }

  function nearestFood(o, range, grid, cell = 48) {
    let target = null;
    let td = range;
    const cx = Math.floor(o.x / cell);
    const cy = Math.floor(o.y / cell);
    for (let gx = cx - 1; gx <= cx + 1; gx++) {
      for (let gy = cy - 1; gy <= cy + 1; gy++) {
        const list = grid.get(`${gx},${gy}`);
        if (!list) continue;
        for (const f of list) {
          const d = dist(o, f);
          if (d < td) {
            td = d;
            target = f;
          }
        }
      }
    }
    return target;
  }

  function updateBioStep(dtScale = 1) {
    for (const k in bioEffects) bioEffects[k] = Math.max(0, bioEffects[k] - dtScale);

    if (simFrame % 95 === 0 && foods.length < +$('foodRate').value) {
      spawnFood(rand(15, W - 15), rand(15, H - 15), 2);
    }

    const foodGrid = buildFoodGrid();
    const mutBoost = bioEffects.mutation > 0 ? 30 : 0;
    const reproThreshold = bioEffects.mutation > 0 ? 125 : 150;

    for (let i = organisms.length - 1; i >= 0; i--) {
      const o = organisms[i];
      o.age++;
      o.cool--;

      const metabolism = o.kind === 'predator' ? 0.032 : 0.022;
      o.energy -= (metabolism + o.speed * 0.009) * dtScale;

      const vision = o.vision + (bioEffects.sonar > 0 ? 85 : 0);
      let ax = 0;
      let ay = 0;

      if (o.kind === 'grazer') {
        const target = nearestFood(o, vision, foodGrid);
        if (target) {
          const a = angle(o, target);
          ax += Math.cos(a) * 0.06;
          ay += Math.sin(a) * 0.06;
        }
        for (const p of organisms) {
          if (p !== o && p.kind === 'predator') {
            const d = dist(o, p);
            if (d < vision * 0.75 && d > 0) {
              ax += ((o.x - p.x) / d) * 0.14;
              ay += ((o.y - p.y) / d) * 0.14;
            }
          }
        }
      } else {
        let prey = null;
        let pd = vision * 0.85;
        for (const p of organisms) {
          if (p !== o && p.kind === 'grazer') {
            const d = dist(o, p);
            if (d < pd) {
              pd = d;
              prey = p;
            }
          }
        }
        if (prey) {
          const a = angle(o, prey);
          ax += Math.cos(a) * 0.052;
          ay += Math.sin(a) * 0.052;
          if (pd < o.r + prey.r + 4) {
            prey.energy -= 1.1 * dtScale;
            o.energy += 0.35 * dtScale;
          }
        }
      }

      for (const h of obstacles) {
        const cx = (h.x + h.x2) / 2;
        const cy = (h.y + h.y2) / 2;
        const d = dist(o, { x: cx, y: cy });
        const range = (h.type === 'lava' ? 78 : 42) + o.r;
        if (d < range && d > 0) {
          ax += ((o.x - cx) / d) * 0.17;
          ay += ((o.y - cy) / d) * 0.17;
        }
        if (h.type === 'lava' && pointSegmentDistance(o, h) < o.r + 12 && bioEffects.shield <= 0) {
          o.energy -= 0.5 * dtScale;
        }
      }

      o.vx = (o.vx + ax) * 0.985;
      o.vy = (o.vy + ay) * 0.985;
      const sp = Math.hypot(o.vx, o.vy);
      const max = o.speed;
      if (sp > max) {
        o.vx = (o.vx / sp) * max;
        o.vy = (o.vy / sp) * max;
      }
      o.x += o.vx * dtScale;
      o.y += o.vy * dtScale;
      if (o.x < o.r || o.x > W - o.r) o.vx *= -1;
      if (o.y < o.r || o.y > H - o.r) o.vy *= -1;
      o.x = clamp(o.x, o.r, W - o.r);
      o.y = clamp(o.y, o.r, H - o.r);

      for (let j = foods.length - 1; j >= 0; j--) {
        if (dist(o, foods[j]) < o.r + foods[j].r + 2) {
          o.energy += foods[j].energy;
          foods.splice(j, 1);
          break;
        }
      }

      if (o.kind === 'predator') {
        for (let j = organisms.length - 1; j >= 0; j--) {
          const p = organisms[j];
          if (p !== o && p.kind === 'grazer' && dist(o, p) < o.r + p.r + 2 && p.energy <= 0) {
            o.energy += 18;
            organisms.splice(j, 1);
            logEvent('death', 'Săn mồi tiêu diệt sinh vật ăn cỏ.');
            if (selectedBio === p) selectedBio = null;
            break;
          }
        }
      }

      if (o.energy > reproThreshold && o.cool < 0 && organisms.length < 200) {
        o.energy *= 0.52;
        o.cool = 240;
        const child = makeOrganism(o.x + rand(-10, 10), o.y + rand(-10, 10), o);
        logEvent('birth', `Sinh sản thế hệ ${child.gen}.`);
        if (Math.random() * 100 < +$('mutation').value + mutBoost) {
          o.hue = (o.hue + rand(-35, 35) + 360) % 360;
        }
      }

      if (o.energy <= 0 || o.age > o.maxAge) {
        organisms.splice(i, 1);
        logEvent('death', o.kind === 'predator' ? 'Săn mồi chết (hết năng lượng/tuổi).' : 'Sinh vật chết.');
        if (selectedBio === o) selectedBio = null;
      }
    }

    if (prevOrganismCount > 0 && organisms.length === 0 && !extinctionLogged) {
      extinctionLogged = true;
      logEvent('death', 'Tuyệt chủng: không còn sinh vật trong hệ sinh thái.');
    }
    prevOrganismCount = organisms.length;
  }

  function absorbInto(eater, food) {
    if (food.dead || eater.dead) return;
    eater.mass += food.mass * 0.85;
    eater.r =
      eater.type === 'blackhole'
        ? Math.min(52, Math.sqrt(eater.mass) * 0.85)
        : Math.sqrt(eater.mass) * 0.72;
    food.dead = true;
    logEvent('merge', `${food.type} bị hấp thụ bởi ${eater.type}.`);
  }

  function mergeBodies(a, b) {
    if (a.dead || b.dead) return;
    const m1 = a.mass;
    const m2 = b.mass;
    const total = m1 + m2;
    const vx = (a.vx * m1 + b.vx * m2) / total;
    const vy = (a.vy * m1 + b.vy * m2) / total;
    if (m1 >= m2) {
      a.mass = total;
      a.vx = vx;
      a.vy = vy;
      a.r = Math.sqrt(a.mass) * 0.72;
      b.dead = true;
    } else {
      b.mass = total;
      b.vx = vx;
      b.vy = vy;
      b.r = Math.sqrt(b.mass) * 0.72;
      a.dead = true;
    }
    logEvent('merge', 'Hai thiên thể va chạm và hợp nhất (bảo toàn động lượng).');
  }

  function updateGravityStep() {
    if (stasisFrames > 0) {
      stasisFrames--;
      return;
    }
    if (gravityPulse > 0) gravityPulse--;

    const dt = simSpeed * (slow ? 0.35 : 1);
    const soft = 90;
    const activeGravity = gravityPower * (gravityPulse > 0 ? 2.8 : 1);

    for (const b of bodies) {
      if (!b.dead) {
        b.ax = 0;
        b.ay = 0;
      }
    }

    for (let i = 0; i < bodies.length; i++) {
      const a = bodies[i];
      if (a.dead) continue;
      for (let j = i + 1; j < bodies.length; j++) {
        const b = bodies[j];
        if (b.dead) continue;
        const dx = b.x - a.x;
        const dy = b.y - a.y;
        const d2 = dx * dx + dy * dy + soft;
        const d = Math.sqrt(d2);
        const force = (activeGravity * a.mass * b.mass) / d2;
        const accA = force / Math.max(5, a.mass);
        const accB = force / Math.max(5, b.mass);
        const fx = (dx / d) * accA * 0.00075 * dt;
        const fy = (dy / d) * accA * 0.00075 * dt;
        a.vx += fx;
        a.vy += fy;
        a.ax += fx / dt;
        a.ay += fy / dt;
        b.vx -= (dx / d) * accB * 0.00075 * dt;
        b.vy -= (dy / d) * accB * 0.00075 * dt;
        b.ax -= (dx / d) * accB * 0.00075 * dt;
        b.ay -= (dy / d) * accB * 0.00075 * dt;

        const overlap = d < a.r + b.r;
        if (overlap) {
          if (a.type === 'blackhole' || b.type === 'blackhole') {
            const eater = a.type === 'blackhole' ? a : b;
            const food = eater === a ? b : a;
            absorbInto(eater, food);
          } else {
            mergeBodies(a, b);
          }
        }
      }
    }

    for (const a of bodies) {
      if (a.dead) continue;
      a.vx *= 0.999;
      a.vy *= 0.999;
      a.x += a.vx * dt;
      a.y += a.vy * dt;
      if (showTrails) {
        a.trail.push({ x: a.x, y: a.y });
        if (a.trail.length > 75) a.trail.shift();
      } else a.trail.length = 0;
      if (a.x < -120 || a.x > W + 120 || a.y < -120 || a.y > H + 120) a.dead = true;
    }

    const before = bodies.length;
    bodies = bodies.filter((b) => !b.dead);
    if (selectedBody && !bodies.includes(selectedBody)) selectedBody = null;
    if (before > 0 && bodies.length === 0) {
      logEvent('system', 'Không còn thiên thể trên bản đồ.');
    }
  }

  function drawBackground() {
    ctx.fillStyle = game === 'bio' ? '#061018' : '#060812';
    ctx.fillRect(0, 0, W, H);
    if (game === 'gravity') {
      for (const s of stars) {
        ctx.globalAlpha = s.a * (0.75 + 0.25 * Math.sin(simFrame * 0.025 + s.p));
        ctx.fillStyle = '#c8d8ff';
        ctx.beginPath();
        ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalAlpha = 1;
      ctx.strokeStyle = '#11172a';
      for (let r = 60; r < Math.min(W, H); r += 60) {
        ctx.beginPath();
        ctx.arc(W / 2, H / 2, r, 0, Math.PI * 2);
        ctx.stroke();
      }
    } else {
      ctx.strokeStyle = '#102632';
      for (let x = 0; x < W; x += 36) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, H);
        ctx.stroke();
      }
      for (let y = 0; y < H; y += 36) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(W, y);
        ctx.stroke();
      }
      const g = ctx.createRadialGradient(W * 0.5, H * 0.5, 0, W * 0.5, H * 0.5, Math.max(W, H) * 0.65);
      g.addColorStop(0, '#103b4522');
      g.addColorStop(1, '#06101800');
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, W, H);
    }
  }

  function drawBio() {
    for (const h of obstacles) {
      if (h.type === 'lava') {
        ctx.strokeStyle = '#ff875a';
        ctx.lineWidth = 22;
        ctx.lineCap = 'round';
        ctx.shadowBlur = 18;
        ctx.shadowColor = '#ff6538';
        ctx.beginPath();
        ctx.moveTo(h.x, h.y);
        ctx.lineTo(h.x2, h.y2);
        ctx.stroke();
        ctx.shadowBlur = 0;
      } else {
        ctx.strokeStyle = '#304859';
        ctx.lineWidth = 18;
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(h.x, h.y);
        ctx.lineTo(h.x2, h.y2);
        ctx.stroke();
      }
    }
    for (const f of foods) {
      ctx.shadowColor = '#28d9c3';
      ctx.shadowBlur = 10;
      ctx.fillStyle = '#62f5d5';
      ctx.beginPath();
      ctx.arc(f.x, f.y, f.r, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;
    }
    for (const o of organisms) {
      const color = o.kind === 'predator' ? '#ff6b81' : `hsl(${o.hue},85%,65%)`;

      // Vòng tầm nhìn khi được chọn
      if (o === selectedBio) {
        ctx.strokeStyle = '#ffffff88';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.arc(o.x, o.y, o.vision, 0, Math.PI * 2);
        ctx.stroke();
      }

      ctx.save();
      ctx.translate(o.x, o.y);
      ctx.rotate(Math.atan2(o.vy, o.vx));

      // Thân sinh vật phong cách Anime/Chibi — ellipse ngang
      ctx.shadowColor = color;
      ctx.shadowBlur = o.gen > 2 ? 12 : 5;
      ctx.fillStyle = color;
      ctx.beginPath();
      ctx.ellipse(0, 0, o.r * 1.3, o.r, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;

      // Mắt anime to tròn
      ctx.fillStyle = '#fff';
      ctx.beginPath();
      ctx.arc(o.r * 0.4, -o.r * 0.35, o.r * 0.3, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.arc(o.r * 0.4, o.r * 0.35, o.r * 0.3, 0, Math.PI * 2);
      ctx.fill();
      // Đồng tử
      ctx.fillStyle = o.kind === 'predator' ? '#c0392b' : '#1a6b5a';
      ctx.beginPath();
      ctx.arc(o.r * 0.45, -o.r * 0.35, o.r * 0.14, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.arc(o.r * 0.45, o.r * 0.35, o.r * 0.14, 0, Math.PI * 2);
      ctx.fill();

      // Sừng/Tai đột biến xuất hiện từ thế hệ 3 trở lên
      if (o.gen >= 3) {
        ctx.strokeStyle = color;
        ctx.lineWidth = 1.8;
        ctx.lineJoin = 'round';
        ctx.beginPath();
        ctx.moveTo(0, -o.r);
        ctx.lineTo(o.r * 0.5, -o.r * 1.5);
        ctx.moveTo(0, o.r);
        ctx.lineTo(o.r * 0.5, o.r * 1.5);
        ctx.stroke();
      }

      ctx.restore();
    }
    if (organisms.length === 0) {
      ctx.fillStyle = '#d9e9f7';
      ctx.font = '16px system-ui';
      ctx.textAlign = 'center';
      ctx.fillText('Hệ sinh thái đã sụp đổ.', W / 2, H / 2 - 8);
      ctx.font = '12px system-ui';
      ctx.fillStyle = '#8ea2b9';
      ctx.fillText('Rải thức ăn hoặc tạo thế giới mới.', W / 2, H / 2 + 16);
      ctx.textAlign = 'left';
    }
  }

  function drawGravity() {
    for (const b of bodies) {
      if (b.trail.length > 1 && showTrails) {
        ctx.beginPath();
        ctx.moveTo(b.trail[0].x, b.trail[0].y);
        for (const p of b.trail) ctx.lineTo(p.x, p.y);
        ctx.strokeStyle = b.type === 'blackhole' ? '#a78bfa55' : `hsla(${b.hue},85%,70%,.35)`;
        ctx.lineWidth = b.type === 'blackhole' ? 1.8 : 1;
        ctx.stroke();
      }
      if (b.type === 'blackhole') {
        const glow = ctx.createRadialGradient(b.x, b.y, b.r * 0.4, b.x, b.y, b.r * 3.8);
        glow.addColorStop(0, '#000');
        glow.addColorStop(0.45, '#4c267d99');
        glow.addColorStop(1, '#a78bfa00');
        ctx.fillStyle = glow;
        ctx.beginPath();
        ctx.arc(b.x, b.y, b.r * 3.8, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#02030a';
        ctx.beginPath();
        ctx.arc(b.x, b.y, b.r * 0.9, 0, Math.PI * 2);
        ctx.fill();
      } else {
        const g = ctx.createRadialGradient(b.x - b.r * 0.35, b.y - b.r * 0.4, 0, b.x, b.y, b.r * 1.5);
        g.addColorStop(0, b.type === 'sun' ? '#fff3bd' : `hsl(${b.hue},75%,82%)`);
        g.addColorStop(0.45, b.type === 'sun' ? '#ffb454' : `hsl(${b.hue},70%,52%)`);
        g.addColorStop(1, b.type === 'sun' ? '#a74327' : `hsl(${b.hue},75%,25%)`);
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(b.x, b.y, b.r, 0, Math.PI * 2);
        ctx.fill();
      }
      if (b === selectedBody) {
        ctx.strokeStyle = '#fff';
        ctx.setLineDash([4, 4]);
        ctx.beginPath();
        ctx.arc(b.x, b.y, b.r + 10, 0, Math.PI * 2);
        ctx.stroke();
        ctx.setLineDash([]);
      }
      if (showVectors) {
        ctx.strokeStyle = '#e8dcff';
        ctx.beginPath();
        ctx.moveTo(b.x, b.y);
        ctx.lineTo(b.x + b.vx * 4, b.y + b.vy * 4);
        ctx.stroke();
        ctx.strokeStyle = '#ff9b5499';
        ctx.beginPath();
        ctx.moveTo(b.x, b.y);
        ctx.lineTo(b.x + b.ax * 120, b.y + b.ay * 120);
        ctx.stroke();
      }
    }
    if (dragStart && dragNow) {
      ctx.strokeStyle = '#f1edff';
      ctx.setLineDash([5, 5]);
      ctx.beginPath();
      ctx.moveTo(dragStart.x, dragStart.y);
      ctx.lineTo(dragNow.x, dragNow.y);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = '#d8ccff';
      ctx.font = '11px system-ui';
      ctx.fillText('VECTOR VẬN TỐC', dragStart.x + 8, dragStart.y - 10);
    }
    if (bodies.length === 0) {
      ctx.fillStyle = '#d9e9f7';
      ctx.font = '16px system-ui';
      ctx.textAlign = 'center';
      ctx.fillText('Vũ trụ trống.', W / 2, H / 2 - 8);
      ctx.font = '12px system-ui';
      ctx.fillStyle = '#8ea2b9';
      ctx.fillText('Nhấp canvas để tạo thiên thể hoặc dùng Thế giới mới.', W / 2, H / 2 + 16);
      ctx.textAlign = 'left';
    }
  }

  function updateStats() {
    if (game === 'bio') {
      const avg = organisms.length ? organisms.reduce((s, o) => s + o.energy, 0) / organisms.length : 0;
      $('s1').textContent = organisms.length;
      $('s2').textContent = foods.length;
      $('s3').textContent = Math.round(avg);
      $('s4').textContent = String(organisms.reduce((m, o) => Math.max(m, o.gen), 0)).padStart(2, '0');
    } else {
      $('g1').textContent = bodies.length;
      $('g2').textContent = bodies.filter((b) => b.type === 'blackhole').length;
      $('g3').textContent = Math.round(bodies.reduce((s, b) => s + b.mass, 0));
      $('g4').textContent = simSpeed.toFixed(1);
    }
  }

  function simStep() {
    simFrame++;
    const dtScale = slow ? 0.35 : 1;
    if (game === 'bio') {
      updateBioStep(dtScale);
      updateAdvancedBioStep(dtScale);
    } else updateGravityStep();
    pushHistory();
  }

  function loop(now) {
    requestAnimationFrame(loop);
    const delta = Math.min(0.1, (now - lastTime) / 1000);
    lastTime = now;
    if (running) {
      accTime += delta;
      let steps = 0;
      while (accTime >= FIXED_DT && steps < MAX_STEPS) {
        simStep();
        accTime -= FIXED_DT;
        steps++;
      }
    }
    drawBackground();
    if (game === 'bio') { drawBio(); drawAdvancedBio(); }
    else drawGravity();
    if (simFrame % 8 === 0) {
      updateStats();
      updateInspectPanel();
    }
  }

  document.querySelectorAll('.tab').forEach((b) =>
    b.addEventListener('click', () => setGame(b.dataset.game))
  );

  $('pauseBtn').onclick = () => {
    running = !running;
    updatePauseUI();
  };

  $('resetBtn').onclick = () => {
    if (game === 'bio') newBio();
    else newGravity();
  };

  $('clearBtn').onclick = () => {
    const msg =
      game === 'bio'
        ? 'Xóa toàn bộ sinh vật, thức ăn và chướng ngại vật?'
        : 'Xóa toàn bộ thiên thể?';
    if (!confirm(msg)) return;
    if (game === 'bio') {
      organisms = [];
      foods = [];
      obstacles = [];
      structures = [];
      selectedBio = null;
      extinctionLogged = true;
      logEvent('system', 'Người dùng xóa toàn bộ sinh quyển.');
    } else {
      bodies = [];
      selectedBody = null;
      logEvent('system', 'Người dùng xóa toàn bộ thiên thể.');
    }
    updateInspectPanel();
  };

  $('deleteSelectedBtn').onclick = () => {
    if (game === 'bio' && selectedBio) {
      organisms = organisms.filter((o) => o !== selectedBio);
      logEvent('death', 'Đã xóa sinh vật được chọn.');
      selectedBio = null;
    } else if (game === 'gravity' && selectedBody) {
      bodies = bodies.filter((b) => b !== selectedBody);
      logEvent('system', 'Đã xóa thiên thể được chọn.');
      selectedBody = null;
    }
    updateInspectPanel();
  };

  // Nút chuyển đổi giao diện Sáng / Tối
  $('themeToggleBtn').onclick = () => {
    document.body.classList.toggle('light-mode');
    $('themeToggleBtn').textContent = document.body.classList.contains('light-mode')
      ? '🌙 Tối'
      : '☀️ Sáng / Tối';
  };

  // Nút nhân bản sinh vật đang được chọn
  $('duplicateBioBtn').onclick = () => {
    if (game === 'bio' && selectedBio && organisms.includes(selectedBio)) {
      makeOrganism(selectedBio.x + 15, selectedBio.y + 15, selectedBio);
      logEvent('birth', `Đã nhân bản sinh vật thế hệ ${selectedBio.gen}.`);
      updateInspectPanel();
    }
  };

  // --- CHỦNG TỘC & CHIẾN TRANH ---

  // 🛡️ Tạo 8 sinh vật bản địa (grazer + builder) phân tán trên bản đồ
  $('spawnNativeBtn').onclick = () => {
    if (game !== 'bio') return;
    const kinds = ['grazer', 'grazer', 'grazer', 'grazer', 'builder', 'builder', 'grazer', 'builder'];
    kinds.forEach(k => makeAdvancedOrganism(rand(30, W - 30), rand(30, H - 30), null, k));
    spawnFood(W / 2, H / 2, 20);
    AudioFX.play('bloom');
    logEvent('birth', `🛡️ Triệu hồi 8 sinh vật bản địa (grazer & builder).`);
  };

  // ⚔️ Tạo 5 chủng tộc xâm lược
  $('spawnInvaderBtn').onclick = () => {
    if (game !== 'bio') return;
    for (let i = 0; i < 5; i++) {
      makeAdvancedOrganism(rand(30, W - 30), rand(30, H - 30), null, 'invader');
    }
    AudioFX.play('supernova');
    logEvent('death', `⚔️ 5 chủng xâm lược xuất hiện trên bản đồ!`);
  };

  // ⚡ Đột biến toàn bộ sinh vật bản địa: tăng tốc, thị giác, kích thước
  $('mutateNativeBtn').onclick = () => {
    if (game !== 'bio') return;
    let count = 0;
    organisms.forEach(o => {
      if (o.kind === 'grazer' || o.kind === 'builder') {
        o.speed  = clamp(o.speed  * 1.25, 0.8, 2.6);
        o.vision = clamp(o.vision * 1.2,  60,  160);
        o.r      = clamp(o.r + 0.8, 3.5, 9);
        o.energy = Math.min(o.energy + 30, 150);
        o.hue    = (o.hue + rand(-20, 20) + 360) % 360; // Đột biến màu
        count++;
      }
    });
    AudioFX.play('mutation');
    logEvent('birth', `⚡ Đột biến ${count} sinh vật bản địa — tiến hóa vượt bậc!`);
  };

  // 🗡️ Trang bị vũ khí bản địa: tăng tốc độ + phục hồi năng lượng
  $('nativeEquipBtn').onclick = () => {
    if (game !== 'bio') return;
    let count = 0;
    organisms.forEach(o => {
      if (o.kind === 'grazer' || o.kind === 'builder') {
        o.speed  = clamp(o.speed + 0.3, 0.8, 2.6);
        o.energy = Math.min(o.energy + 20, 150);
        o.equipped = true;
        count++;
      }
    });
    AudioFX.play('shield');
    logEvent('system', `🗡️ Vũ khí trang bị cho ${count} bản địa — tốc độ & năng lượng tăng.`);
  };

  // 🏹 Trang bị vũ khí xâm lược: tăng tầm nhìn + sức mạnh tấn công
  $('invaderEquipBtn').onclick = () => {
    if (game !== 'bio') return;
    let count = 0;
    organisms.forEach(o => {
      if (o.kind === 'invader') {
        o.vision  = clamp(o.vision + 25, 80, 200);
        o.r       = clamp(o.r + 1,    5,  11);
        o.energy  = Math.min(o.energy + 25, 150);
        o.equipped = true;
        count++;
      }
    });
    AudioFX.play('gravityPulse');
    logEvent('death', `🏹 Xâm lược được trang bị (${count} cá thể) — tầm nhìn & kích thước tăng!`);
  };

  function bindRange(id, out, format = (v) => v) {
    $(id).addEventListener('input', (e) => {
      $(out).textContent = format(e.target.value);
    });
  }
  bindRange('population', 'populationOut');
  bindRange('foodRate', 'foodRateOut');
  bindRange('mutation', 'mutationOut', (v) => v + '%');
  bindRange('mass', 'massOut');
  bindRange('gravity', 'gravityOut', (v) => (v / 10).toFixed(1) + '×');
  bindRange('gravSpeed', 'gravSpeedOut', (v) => (v / 10).toFixed(1) + '×');

  $('feedBtn').onclick = () => {
    $('bioTool').value = 'food';
    syncBioToolButtons();
    for (let i = 0; i < 28; i++) spawnFood();
    $('eventText').textContent = 'Đã bổ sung thức ăn.';
  };
  $('hazardBtn').onclick = () => {
    $('bioTool').value = 'lava';
    syncBioToolButtons();
    $('eventText').textContent = 'Chế độ vẽ dung nham — kéo trên bản đồ.';
  };
  $('bioTool').onchange = syncBioToolButtons;

  $('orbitBtn').onclick = () => {
    orbitAssist = !orbitAssist;
    $('orbitBtn').classList.toggle('selected', orbitAssist);
  };
  $('trailBtn').onclick = () => {
    showTrails = !showTrails;
    $('trailBtn').classList.toggle('selected', showTrails);
    $('trailBtn').textContent = showTrails ? '〰 Vệt quỹ đạo: bật' : '〰 Vệt quỹ đạo: tắt';
  };
  $('vectorBtn').onclick = () => {
    showVectors = !showVectors;
    $('vectorBtn').classList.toggle('selected', showVectors);
  };

  $('burstBtn').onclick = () => {
    for (let i = 0; i < 45; i++) {
      const x = rand(0, W);
      const y = rand(0, H);
      const a = rand(0, Math.PI * 2);
      bodies.push(
        bodyDefaults('asteroid', rand(3, 12), x, y, Math.cos(a) * rand(-2, 2), Math.sin(a) * rand(-2, 2))
      );
      bodies[bodies.length - 1].r = rand(2, 4);
    }
    logEvent('system', 'Mưa tiểu hành tinh.');
  };
  $('gravityWellBtn').onclick = () => {
    bodies.push(
      bodyDefaults(
        'blackhole',
        160,
        W / 2 + rand(-W * 0.2, W * 0.2),
        H / 2 + rand(-H * 0.2, H * 0.2),
        0,
        0
      )
    );
    logEvent('system', 'Thêm hố đen mới.');
  };

  $('slowBtn').onclick = () => {
    slow = !slow;
    $('slowBtn').classList.toggle('selected', slow);
    $('slowBtn').textContent = slow ? '◴ Chậm: bật' : '◴ Chuyển động chậm';
  };

  $('randomBtn').onclick = () => {
    if (game === 'bio') {
      spawnFood(rand(30, W - 30), rand(30, H - 30), 35);
      if (Math.random() < 0.6) {
        addObstacle(
          rand(20, W - 20),
          rand(20, H - 20),
          rand(20, W - 20),
          rand(20, H - 20),
          Math.random() < 0.5 ? 'lava' : 'rock'
        );
      }
      $('eventText').textContent = 'Sự kiện sinh thái ngẫu nhiên.';
      logEvent('system', 'Sự kiện sinh thái ngẫu nhiên.');
    } else {
      if (Math.random() < 0.5) $('burstBtn').click();
      else $('gravityWellBtn').click();
      $('eventText').textContent = 'Sự kiện vũ trụ ngẫu nhiên.';
    }
  };

  $('gravity').addEventListener('input', (e) => {
    gravityPower = +e.target.value / 10;
  });
  $('gravSpeed').addEventListener('input', (e) => {
    simSpeed = +e.target.value / 10;
  });

  function skillButton(id, cooldown, action, infoId, message, soundType = 'default') {
    const btn = $(id);
    btn.addEventListener('click', () => {
      const now = performance.now();
      const ready = skillCooldown[id] || 0;
      if (now < ready) return;
      action();
      if (typeof AudioFX !== 'undefined') AudioFX.playSkillSound(soundType);
      skillCooldown[id] = now + cooldown;
      $(infoId).textContent = message;
      btn.disabled = true;
      btn.classList.remove('skill-ready');
      const tick = () => {
        const left = skillCooldown[id] - performance.now();
        if (left <= 0) {
          btn.disabled = false;
          btn.classList.add('skill-ready');
          btn.title = 'Sẵn sàng';
        } else {
          btn.title = 'Hồi chiêu: ' + Math.ceil(left / 1000) + ' giây';
          setTimeout(tick, 250);
        }
      };
      tick();
    });
  }

  skillButton(
    'skillBloom',
    9000,
    () => {
      for (let i = 0; i < 55; i++) spawnFood(rand(25, W - 25), rand(25, H - 25));
      logEvent('system', 'Kỹ năng: bùng nổ thức ăn.');
    },
    'bioSkillInfo',
    'Bùng nổ thức ăn (+55). Hồi 9 giây.',
    'bloom'
  );
  skillButton(
    'skillSonar',
    12000,
    () => {
      bioEffects.sonar = 420;
      logEvent('system', 'Kỹ năng: xung dò tìm.');
    },
    'bioSkillInfo',
    'Xung dò tìm ~7 giây. Hồi 12 giây.'
  );
  skillButton(
    'skillShield',
    15000,
    () => {
      bioEffects.shield = 480;
      logEvent('system', 'Kỹ năng: lá chắn sinh thái.');
    },
    'bioSkillInfo',
    'Lá chắn chống dung nham ~8 giây. Hồi 15 giây.'
  );
  skillButton(
    'skillMutation',
    18000,
    () => {
      bioEffects.mutation = 600;
      logEvent('system', 'Kỹ năng: đột biến nhanh.');
    },
    'bioSkillInfo',
    'Đột biến nhanh ~10 giây. Hồi 18 giây.'
  );
  skillButton(
    'skillGravityPulse',
    12000,
    () => {
      gravityPulse = 360;
      logEvent('system', 'Kỹ năng: xung hấp dẫn.');
    },
    'gravitySkillInfo',
    'Xung hấp dẫn ×2.8 ~6 giây. Hồi 12 giây.',
    'pulse'
  );
  skillButton(
    'skillStasis',
    16000,
    () => {
      stasisFrames = 180;
      logEvent('system', 'Kỹ năng: đóng băng thời gian.');
    },
    'gravitySkillInfo',
    'Đóng băng ~3 giây. Hồi 16 giây.'
  );
  skillButton(
    'skillSupernova',
    20000,
    () => {
      const x = W / 2;
      const y = H / 2;
      for (let i = 0; i < 24; i++) {
        const a = (i / 24) * Math.PI * 2;
        const v = rand(1.5, 4);
        bodies.push(
          bodyDefaults('asteroid', rand(4, 10), x + rand(-10, 10), y + rand(-10, 10), Math.cos(a) * v, Math.sin(a) * v)
        );
      }
      logEvent('merge', 'Siêu tân tinh phóng 24 mảnh vật chất.');
    },
    'gravitySkillInfo',
    'Siêu tân tinh. Hồi 20 giây.',
    'supernova'
  );
  skillButton(
    'skillScatter',
    14000,
    () => {
      for (let i = 0; i < 35; i++) {
        const a = rand(0, Math.PI * 2);
        const r = rand(20, Math.min(W, H) * 0.25);
        bodies.push(
          bodyDefaults(
            'asteroid',
            rand(3, 9),
            W / 2 + Math.cos(a) * r,
            H / 2 + Math.sin(a) * r,
            rand(-2.5, 2.5),
            rand(-2.5, 2.5)
          )
        );
      }
      logEvent('system', 'Phân tán 35 tiểu hành tinh.');
    },
    'gravitySkillInfo',
    'Phân tán tiểu hành tinh. Hồi 14 giây.'
  );

  $('toggleSidebarBtn').onclick = () => {
    $('app').classList.toggle('sidebar-collapsed');
  };

  $('saveConfigBtn').onclick = () => {
    const data = {
      game,
      population: $('population').value,
      foodRate: $('foodRate').value,
      mutation: $('mutation').value,
      mass: $('mass').value,
      gravity: $('gravity').value,
      gravSpeed: $('gravSpeed').value,
      orbitAssist,
      showTrails,
      showVectors,
    };
    localStorage.setItem(SAVE_KEY, JSON.stringify(data));
    logEvent('system', 'Đã lưu cấu hình thí nghiệm.');
    $('eventText').textContent = 'Cấu hình đã lưu vào trình duyệt.';
  };

  $('loadConfigBtn').onclick = () => {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) {
      alert('Chưa có cấu hình đã lưu.');
      return;
    }
    try {
      const data = JSON.parse(raw);
      $('population').value = data.population ?? 48;
      $('foodRate').value = data.foodRate ?? 70;
      $('mutation').value = data.mutation ?? 18;
      $('mass').value = data.mass ?? 30;
      $('gravity').value = data.gravity ?? 10;
      $('gravSpeed').value = data.gravSpeed ?? 10;
      orbitAssist = data.orbitAssist ?? true;
      showTrails = data.showTrails ?? true;
      showVectors = data.showVectors ?? true;
      $('populationOut').textContent = $('population').value;
      $('foodRateOut').textContent = $('foodRate').value;
      $('mutationOut').textContent = $('mutation').value + '%';
      $('massOut').textContent = $('mass').value;
      $('gravityOut').textContent = (+$('gravity').value / 10).toFixed(1) + '×';
      $('gravSpeedOut').textContent = (+$('gravSpeed').value / 10).toFixed(1) + '×';
      gravityPower = +$('gravity').value / 10;
      simSpeed = +$('gravSpeed').value / 10;
      $('orbitBtn').classList.toggle('selected', orbitAssist);
      $('trailBtn').classList.toggle('selected', showTrails);
      $('vectorBtn').classList.toggle('selected', showVectors);
      if (data.game) setGame(data.game);
      logEvent('system', 'Đã khôi phục cấu hình.');
      $('eventText').textContent = 'Cấu hình đã khôi phục.';
    } catch {
      alert('Không đọc được cấu hình đã lưu.');
    }
  };

  $('exportCsvBtn').onclick = () => {
    if (!history.length) {
      alert('Chưa có dữ liệu lịch sử để xuất.');
      return;
    }
    const headers = Object.keys(history[0]);
    const lines = [headers.join(',')].concat(
      history.map((row) => headers.map((h) => row[h]).join(','))
    );
    const blob = new Blob([lines.join('\n')], { type: 'text/csv;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `thegioisong_${game}_${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(a.href);
    logEvent('system', 'Đã xuất CSV lịch sử mô phỏng.');
  };

  $('clearLogBtn').onclick = () => {
    if (!confirm('Xóa toàn bộ nhật ký sự kiện?')) return;
    events.length = 0;
    renderEventLog();
  };

  $('welcomeOk').onclick = () => {
    $('welcomeModal').classList.add('hidden');
    localStorage.setItem(WELCOME_KEY, '1');
  };

  function loadUsers() {
    try {
      const raw = localStorage.getItem(USERS_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  }

  function saveUsers(users) {
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
  }

  function encodePass(pass) {
    return btoa(unescape(encodeURIComponent(pass)));
  }

  function loadSession() {
    try {
      const raw = localStorage.getItem(SESSION_KEY);
      if (!raw) return null;
      const { userId } = JSON.parse(raw);
      const user = loadUsers().find((u) => u.id === userId);
      return user || null;
    } catch {
      return null;
    }
  }

  function setSession(user) {
    currentUser = user;
    if (user) {
      localStorage.setItem(SESSION_KEY, JSON.stringify({ userId: user.id }));
    } else {
      localStorage.removeItem(SESSION_KEY);
    }
    updateAuthUI();
  }

  function showAuthMsg(el, text, ok) {
    el.textContent = text;
    el.classList.remove('hidden', 'error', 'ok');
    el.classList.add(ok ? 'ok' : 'error');
  }

  function hideAuthMsg(el) {
    el.classList.add('hidden');
    el.textContent = '';
  }

  function setAuthFormMode(mode) {
    const loggedIn = mode === 'profile';
    $('authTabBar').classList.toggle('hidden', loggedIn);
    $('loginForm').classList.toggle('hidden', loggedIn || mode !== 'login');
    $('registerForm').classList.toggle('hidden', loggedIn || mode !== 'register');
    $('profilePanel').classList.toggle('hidden', !loggedIn);
    $('authModalTitle').textContent = loggedIn
      ? 'Hồ sơ cá nhân'
      : 'Tài khoản Thế Giới Sống';
    document.querySelectorAll('.auth-tab').forEach((t) => {
      t.classList.toggle('active', t.dataset.form === mode);
    });
  }

  function openAuthModal() {
    hideAuthMsg($('loginMsg'));
    hideAuthMsg($('registerMsg'));
    if (currentUser) {
      $('profileName').textContent = currentUser.name;
      $('profileEmail').textContent = currentUser.email;
      setAuthFormMode('profile');
    } else {
      setAuthFormMode('login');
    }
    $('authModal').classList.remove('hidden');
  }

  function closeAuthModal() {
    $('authModal').classList.add('hidden');
  }

  function updateAuthUI() {
    const btn = $('openAuthBtn');
    if (currentUser) {
      btn.textContent = `👤 ${currentUser.name}`;
      btn.classList.add('logged-in');
      btn.title = 'Xem hồ sơ cá nhân';
    } else {
      btn.textContent = '👤 Đăng nhập';
      btn.classList.remove('logged-in');
      btn.title = 'Đăng nhập hoặc đăng ký';
    }
  }

  $('openAuthBtn').onclick = openAuthModal;
  $('closeAuthBtn').onclick = closeAuthModal;
  $('profileCloseBtn').onclick = closeAuthModal;

  $('authModal').addEventListener('click', (e) => {
    if (e.target === $('authModal')) closeAuthModal();
  });

  document.querySelectorAll('.auth-tab').forEach((tab) => {
    tab.addEventListener('click', () => {
      hideAuthMsg($('loginMsg'));
      hideAuthMsg($('registerMsg'));
      setAuthFormMode(tab.dataset.form);
    });
  });

  $('loginForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const id = $('loginEmail').value.trim();
    const pass = $('loginPass').value;
    const users = loadUsers();
    const key = id.toLowerCase();
    const user = users.find(
      (u) => u.email.toLowerCase() === key || u.name.toLowerCase() === key
    );
    if (!user || user.pass !== encodePass(pass)) {
      showAuthMsg($('loginMsg'), 'Email/tên hoặc mật khẩu không đúng.', false);
      return;
    }
    setSession(user);
    logEvent('system', `Đăng nhập: ${user.name}.`);
    $('loginForm').reset();
    hideAuthMsg($('loginMsg'));
    $('profileName').textContent = user.name;
    $('profileEmail').textContent = user.email;
    setAuthFormMode('profile');
  });

  $('registerForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const name = $('regName').value.trim();
    const email = $('regEmail').value.trim().toLowerCase();
    const pass = $('regPass').value;
    if (pass.length < 6) {
      showAuthMsg($('registerMsg'), 'Mật khẩu cần ít nhất 6 ký tự.', false);
      return;
    }
    const users = loadUsers();
    if (users.some((u) => u.email === email)) {
      showAuthMsg($('registerMsg'), 'Email đã được đăng ký.', false);
      return;
    }
    if (users.some((u) => u.name.toLowerCase() === name.toLowerCase())) {
      showAuthMsg($('registerMsg'), 'Tên hiển thị đã tồn tại.', false);
      return;
    }
    const user = {
      id: 'u_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7),
      name,
      email,
      pass: encodePass(pass),
      createdAt: Date.now(),
    };
    users.push(user);
    saveUsers(users);
    setSession(user);
    logEvent('system', `Tài khoản mới: ${name}.`);
    $('registerForm').reset();
    hideAuthMsg($('registerMsg'));
    $('profileName').textContent = user.name;
    $('profileEmail').textContent = user.email;
    setAuthFormMode('profile');
  });

  $('logoutBtn').onclick = () => {
    const name = currentUser?.name;
    setSession(null);
    logEvent('system', name ? `Đăng xuất: ${name}.` : 'Đăng xuất.');
    setAuthFormMode('login');
    closeAuthModal();
  };

  $('forgotPassLink').addEventListener('click', (e) => {
    e.preventDefault();
    const email = prompt(
      'Nhập email đã đăng ký để đặt mật khẩu mới (lưu trên trình duyệt này):'
    );
    if (!email) return;
    const key = email.trim().toLowerCase();
    const users = loadUsers();
    const user = users.find((u) => u.email === key);
    if (!user) {
      alert('Không tìm thấy email trong hệ thống local.');
      return;
    }
    const pass = prompt('Mật khẩu mới (ít nhất 6 ký tự):');
    if (!pass || pass.length < 6) {
      alert('Mật khẩu không hợp lệ.');
      return;
    }
    user.pass = encodePass(pass);
    saveUsers(users);
    alert('Đã cập nhật mật khẩu. Bạn có thể đăng nhập lại.');
  });

  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && !$('authModal').classList.contains('hidden')) {
      closeAuthModal();
      return;
    }
    if (e.target.matches('input, select, textarea')) return;
    if (e.code === 'Space') {
      e.preventDefault();
      running = !running;
      updatePauseUI();
    }
    if (e.key === 'b' || e.key === 'B') $('toggleSidebarBtn').click();
  });

  window.addEventListener('resize', resize);

  resize();
  newBio();
  newGravity();
  document.querySelectorAll('#bioSkills button, #gravitySkills button').forEach((b) =>
    b.classList.add('skill-ready')
  );
  syncBioToolButtons();
  setGame('bio');
  setSession(loadSession());
  if (!localStorage.getItem(WELCOME_KEY)) $('welcomeModal').classList.remove('hidden');
  renderEventLog();

  // =====================================================================
  // 4 CHỦNG LOẠI SINH VẬT & CÔNG TRÌNH
  // =====================================================================

  // Tạo sinh vật với 4 chủng loại: grazer | predator | builder | invader
  function makeAdvancedOrganism(x = rand(20, W - 20), y = rand(20, H - 20), parent = null, forcedKind = null) {
    const kind = forcedKind || (parent ? parent.kind : (() => {
      const r = Math.random();
      return r < 0.45 ? 'grazer' : r < 0.70 ? 'predator' : r < 0.90 ? 'builder' : 'invader';
    })());
    const hueMap = { invader: 0, builder: 120, predator: 340, grazer: 180 };
    const speedMap = { invader: 2.1, predator: 1.8, builder: 1.3, grazer: 1.2 };
    const rMap = { invader: 7.5, predator: 6.5, builder: 5.5, grazer: 5 };
    const o = {
      x, y,
      vx: rand(-1, 1), vy: rand(-1, 1),
      r: parent ? clamp(parent.r + rand(-0.5, 0.5), 3.5, 8.5) : rMap[kind],
      energy: parent ? parent.energy * 0.5 : rand(60, 100),
      speed: parent ? clamp(parent.speed + rand(-0.1, 0.1), 0.7, 2.5) : speedMap[kind],
      vision: kind === 'invader' ? 140 : kind === 'predator' ? 120 : 100,
      hue: hueMap[kind],
      age: 0, gen: parent ? parent.gen + 1 : 1, kind,
      cool: rand(0, 100), maxAge: rand(7000, 10500),
      attackCooldown: 0
    };
    organisms.push(o);
    return o;
  }

  // Logic chiến đấu & xây dựng cho 4 chủng loại
  function updateAdvancedBioStep(dtScale = 1) {
    // Thợ xây xây nhà ở định kỳ
    if (simFrame % 300 === 0 && structures.length < 15) {
      const builders = organisms.filter(o => o.kind === 'builder');
      if (builders.length > 0) {
        const b = builders[Math.floor(Math.random() * builders.length)];
        structures.push({ x: b.x + rand(-20, 20), y: b.y + rand(-20, 20), type: 'house', hp: 100 });
        logEvent('system', '🏠 Thợ xây hoàn thành Nhà ở sinh thái!');
      }
    }

    for (let i = organisms.length - 1; i >= 0; i--) {
      const o = organisms[i];
      o.attackCooldown = Math.max(0, (o.attackCooldown || 0) - dtScale);

      if (o.kind === 'invader') {
        // Xâm chiếm: săn lùng tất cả chủng khác
        let target = null, minD = o.vision;
        for (const other of organisms) {
          if (other !== o) {
            const d = dist(o, other);
            if (d < minD) { minD = d; target = other; }
          }
        }
        if (target) {
          const a = angle(o, target);
          o.vx += Math.cos(a) * 0.08 * dtScale;
          o.vy += Math.sin(a) * 0.08 * dtScale;
          if (minD < o.r + target.r + 5 && o.attackCooldown <= 0) {
            target.energy -= 30 * dtScale;
            o.energy += 16 * dtScale;
            o.attackCooldown = 35;
            logEvent('death', `⚔️ Chủng xâm chiếm tấn công ${target.kind}!`);
          }
        }
      } else if (o.kind === 'predator') {
        // Săn mồi chuyên tấn công grazer
        let prey = null, minPD = o.vision;
        for (const other of organisms) {
          if (other.kind === 'grazer') {
            const d = dist(o, other);
            if (d < minPD) { minPD = d; prey = other; }
          }
        }
        if (prey) {
          const a = angle(o, prey);
          o.vx += Math.cos(a) * 0.065 * dtScale;
          o.vy += Math.sin(a) * 0.065 * dtScale;
          if (minPD < o.r + prey.r + 5 && o.attackCooldown <= 0) {
            prey.energy -= 22 * dtScale;
            o.energy += 12 * dtScale;
            o.attackCooldown = 45;
          }
        }
      } else {
        // Grazer & Builder: né kẻ thù hung hãn
        for (const other of organisms) {
          if (other.kind === 'invader' || other.kind === 'predator') {
            const d = dist(o, other);
            if (d < 80 && d > 0) {
              o.vx += (o.x - other.x) / d * 0.10 * dtScale;
              o.vy += (o.y - other.y) / d * 0.10 * dtScale;
            }
          }
        }
      }
    }
  }

  // Vẽ công trình và 4 chủng sinh vật theo phong cách anime/sci-fi
  function drawAdvancedBio() {
    // Vẽ nhà ở của thợ xây
    for (const s of structures) {
      // Thân nhà
      ctx.fillStyle = '#38bdf8';
      ctx.strokeStyle = '#0284c7';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.rect(s.x - 12, s.y - 10, 24, 20);
      ctx.fill(); ctx.stroke();
      // Mái nhà phong cách anime
      ctx.fillStyle = '#f43f5e';
      ctx.beginPath();
      ctx.moveTo(s.x - 15, s.y - 10);
      ctx.lineTo(s.x, s.y - 24);
      ctx.lineTo(s.x + 15, s.y - 10);
      ctx.closePath(); ctx.fill();
      // Cửa sổ
      ctx.fillStyle = '#fde68a';
      ctx.fillRect(s.x - 4, s.y - 5, 8, 7);
    }

    // Vẽ sinh vật 4 chủng (chỉ builder & invader có ngoại hình đặc biệt riêng;
    // grazer & predator đã được drawBio() vẽ, ở đây vẽ overlay tag chủng)
    for (const o of organisms) {
      if (o.kind !== 'builder' && o.kind !== 'invader') continue;
      const color = o.kind === 'invader' ? '#ef4444' : '#22c55e';

      ctx.save();
      ctx.translate(o.x, o.y);
      ctx.rotate(Math.atan2(o.vy, o.vx));

      // Thân phát sáng
      ctx.shadowColor = color;
      ctx.shadowBlur = o.kind === 'invader' ? 18 : 9;
      ctx.fillStyle = color;
      ctx.beginPath();
      ctx.ellipse(0, 0, o.r * 1.4, o.r, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;

      // Mắt anime
      ctx.fillStyle = '#fff';
      ctx.beginPath();
      ctx.arc(o.r * 0.4, -o.r * 0.35, o.r * 0.32, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.arc(o.r * 0.4, o.r * 0.35, o.r * 0.32, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = o.kind === 'invader' ? '#000' : '#0f172a';
      ctx.beginPath();
      ctx.arc(o.r * 0.5, -o.r * 0.35, o.r * 0.14, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.arc(o.r * 0.5, o.r * 0.35, o.r * 0.14, 0, Math.PI * 2);
      ctx.fill();

      if (o.kind === 'invader') {
        // Sừng chiến đấu
        ctx.strokeStyle = '#fca5a5'; ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(0, -o.r); ctx.lineTo(o.r * 0.7, -o.r * 1.8);
        ctx.moveTo(0, o.r);  ctx.lineTo(o.r * 0.7, o.r * 1.8);
        ctx.stroke();
      } else {
        // Builder: ăng-ten công cụ
        ctx.fillStyle = '#fbbf24';
        ctx.beginPath();
        ctx.arc(0, -o.r * 1.4, 3.5, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#fbbf24'; ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(0, -o.r); ctx.lineTo(0, -o.r * 1.4);
        ctx.stroke();
      }

      ctx.restore();
    }
  }

  requestAnimationFrame(loop);
})();
